<?php
include '../coros.php';
header("Content-Type: application/json");

include_once '../config/db.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : null;

if ($id) {
    $stmt = $mysqli->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        echo json_encode([
            "success" => true,
            "data" => $user
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "User not found"
        ]);
    }

    $stmt->close();
} 
$mysqli->close();
