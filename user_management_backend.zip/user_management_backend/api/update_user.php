<?php
include '../coros.php';
header("Content-Type: application/json");
include_once '../config/db.php';

$data = json_decode(file_get_contents("php://input"), true);
$id = $data['id'];
$name = $data['name'];
$email = $data['email'];
$dob = $data['dob'];
$editedBy = $data['editedBy'];
$editedOn = date('Y-m-d H:i:s');

$sql = "UPDATE users SET name='$name', email='$email', dob='$dob', editedBy='$editedBy', editedOn='$editedOn' WHERE id=$id";

if ($mysqli->query($sql)) {
    echo json_encode(["message" => "User updated successfully"]);
} else {
    echo json_encode(["error" => $mysqli->error]);
}

$mysqli->close();
?>
