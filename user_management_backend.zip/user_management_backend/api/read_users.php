<?php
include '../coros.php';
header("Content-Type: application/json");
include_once '../config/db.php';

$sql = "SELECT * FROM users";
$result = $mysqli->query($sql);

$users = [];
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}

echo json_encode($users);

$mysqli->close();
?>
