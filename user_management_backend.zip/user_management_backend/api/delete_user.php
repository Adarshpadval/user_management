<?php
include '../coros.php';
header("Content-Type: application/json");
include_once '../config/db.php';

$data = json_decode(file_get_contents("php://input"), true);
$id = $data['id'];

$sql = "DELETE FROM users WHERE id=$id";

if ($mysqli->query($sql)) {
    echo json_encode(["message" => "User deleted successfully"]);
} else {
    echo json_encode(["error" => $mysqli->error]);
}

$mysqli->close();
?>
