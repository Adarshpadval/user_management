<?php
include '../coros.php';
include_once '../config/db.php';

$data = json_decode(file_get_contents("php://input"));
$name = $data->name;
$email = $data->email;
$password = password_hash($data->password, PASSWORD_BCRYPT);
$dob = $data->dob;
$createBy = $data->createBy;
$createdOn = date('Y-m-d H:i:s');

$sql = "INSERT INTO users (name, email, password, dob, blocked, createBy, createdOn) 
        VALUES ('$name', '$email', '$password', '$dob', false, '$createBy', '$createdOn')";

if ($mysqli->query($sql)) {
    echo json_encode(["message" => "User created successfully"]);
} else {
    echo json_encode(["error" => $mysqli->error]);
}
?>
